# College Canteen Order Management

A console-based canteen ordering system written in core Java (no frameworks, in-memory storage).

## Structure
- `com.canteen.entity` - Student, FoodItem, Order
- `com.canteen.repository` - FoodRepository, OrderRepository
- `com.canteen.service` - FoodService, FoodServiceImpl, OrderService, OrderServiceImpl
- `com.canteen.controller` - CanteenController
- `com.canteen.main` - Main

## Build and run
    cd src
    javac com/canteen/*/*.java
    java com.canteen.main.Main
